import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ShadesService } from './shades.service';
import { ShadesController } from './shades.controller';
import { Shade } from '../entities/shade.entity';
import { CommonModule } from '../common/common.module';

@Module({
  imports: [TypeOrmModule.forFeature([Shade]), CommonModule],
  controllers: [ShadesController],
  providers: [ShadesService],
  exports: [ShadesService],
})
export class ShadesModule {}

