import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNumber, IsOptional, IsBoolean, Min } from 'class-validator';

export class CreateShadeDto {
  @ApiProperty()
  @IsString()
  colorName: string;

  @ApiProperty()
  @IsString()
  color: string; // Hex color code

  @ApiProperty()
  @IsNumber()
  stockId: number;

  @ApiProperty()
  @IsNumber()
  @Min(0)
  rolls: number; // Number of rolls for this shade

  @ApiProperty({ required: false, default: true })
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

