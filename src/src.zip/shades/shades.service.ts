import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Shade } from '../entities/shade.entity';
import { CreateShadeDto } from './dto/create-shade.dto';
import { UpdateShadeDto } from './dto/update-shade.dto';
import { AuditService } from '../common/services/audit.service';

@Injectable()
export class ShadesService {
  constructor(
    @InjectRepository(Shade)
    private shadesRepository: Repository<Shade>,
    private auditService: AuditService,
  ) {}

  async create(createShadeDto: CreateShadeDto, userId?: number): Promise<Shade> {
    const shade = this.shadesRepository.create(createShadeDto);
    const savedShade = await this.shadesRepository.save(shade);
    if (userId) {
      await this.auditService.logChange('shade', 'created', savedShade.id, userId, createShadeDto);
    }
    return savedShade;
  }

  async findAll(): Promise<Shade[]> {
    return this.shadesRepository.find({
      relations: ['stock'],
    });
  }

  // async findByStock(stockId: number): Promise<Shade[]> {
  //   return this.shadesRepository.find({
  //     where: { stockId },
  //   });
  // }

  async findOne(id: number): Promise<Shade> {
    const shade = await this.shadesRepository.findOne({
      where: { id },
      relations: ['stock'],
    });
    if (!shade) {
      throw new NotFoundException(`Shade with ID ${id} not found`);
    }
    return shade;
  }

  async update(id: number, updateShadeDto: UpdateShadeDto, userId?: number): Promise<Shade> {
    const shade = await this.findOne(id);
    const changes: any = {};
    Object.keys(updateShadeDto).forEach((key) => {
      if (shade[key] !== updateShadeDto[key]) {
        changes[key] = { old: shade[key], new: updateShadeDto[key] };
      }
    });
    Object.assign(shade, updateShadeDto);
    const updatedShade = await this.shadesRepository.save(shade);
    if (userId) {
      await this.auditService.logChange('shade', 'updated', id, userId, changes);
    }
    return updatedShade;
  }

  async remove(id: number, userId?: number): Promise<void> {
    const shade = await this.findOne(id);
    await this.shadesRepository.remove(shade);
    if (userId) {
      await this.auditService.logChange('shade', 'deleted', id, userId);
    }
  }
}

