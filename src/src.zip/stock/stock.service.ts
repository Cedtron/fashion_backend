import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Stock } from '../entities/stock.entity';
import { CreateStockDto } from './dto/create-stock.dto';
import { UpdateStockDto } from './dto/update-stock.dto';
import { AdjustStockDto } from './dto/adjust-stock.dto';
import { SearchStockDto } from './dto/search-stock.dto';
import { LogsService } from '../logs/logs.service';

@Injectable()
export class StockService {
  constructor(
    @InjectRepository(Stock)
    private stockRepository: Repository<Stock>,
    private logsService: LogsService,
  ) { }

  async create(createStockDto: CreateStockDto, username: string): Promise<Stock> {
    const stock = this.stockRepository.create({
      ...createStockDto,
      quantity: createStockDto.quantity ?? 0,
    });
    const savedStock = await this.stockRepository.save(stock);

    // Log creation
    await this.logsService.create({
      level: 'info',
      action: 'stock_created',
      message: `Stock item "${savedStock.product}" created by ${username}`,
      details: JSON.stringify({
        stockId: savedStock.id,
        product: savedStock.product,
        category: savedStock.category,
        quantity: savedStock.quantity,
        cost: savedStock.cost,
        price: savedStock.price,
      }),
      userId: username,
    });

    return savedStock;
  }

  async findAll(): Promise<Stock[]> {
    return this.stockRepository.find({
      order: { createdAt: 'DESC' },
    });
  }

  async findOne(id: number): Promise<Stock> {
    const stock = await this.stockRepository.findOne({
      where: { id },
      relations: ['history'],
    });
    if (!stock) {
      throw new NotFoundException(`Stock with ID ${id} not found`);
    }
    return stock;
  }

  async search(searchDto: SearchStockDto): Promise<Stock[]> {
    const queryBuilder = this.stockRepository.createQueryBuilder('stock');

    if (searchDto.product) {
      queryBuilder.andWhere('stock.product LIKE :product', { product: `%${searchDto.product}%` });
    }

    if (searchDto.category) {
      queryBuilder.andWhere('stock.category LIKE :category', { category: `%${searchDto.category}%` });
    }

    if (searchDto.sku) {
      queryBuilder.andWhere('stock.sku LIKE :sku', { sku: `%${searchDto.sku}%` });
    }

    if (searchDto.barcode) {
      queryBuilder.andWhere('stock.barcode = :barcode', { barcode: searchDto.barcode });
    }

    if (searchDto.brand) {
      queryBuilder.andWhere('stock.brand LIKE :brand', { brand: `%${searchDto.brand}%` });
    }

    return queryBuilder.getMany();
  }

  async update(id: number, updateStockDto: UpdateStockDto, username: string): Promise<Stock> {
    const stock = await this.findOne(id);
    const previousQuantity = stock.quantity;
    const changes: any = {};
    Object.keys(updateStockDto).forEach((key) => {
      if (stock[key] !== updateStockDto[key] && updateStockDto[key] !== undefined) {
        changes[key] = {
          old: stock[key],
          new: updateStockDto[key],
        };
      }
    });

    Object.assign(stock, updateStockDto);
    const updatedStock = await this.stockRepository.save(stock);

    // Log update
    await this.logsService.create({
      level: 'info',
      action: 'stock_updated',
      message: `Stock item "${updatedStock.product}" updated by ${username}`,
      details: JSON.stringify({
        stockId: id,
        changes: changes,
        quantityChange: updateStockDto.quantity !== undefined ? {
          previous: previousQuantity,
          new: updatedStock.quantity,
        } : undefined,
      }),
      userId: username,
    });

    return updatedStock;
  }

  async adjustStock(id: number, adjustStockDto: AdjustStockDto, username: string): Promise<Stock> {
    const stock = await this.findOne(id);
    const previousQuantity = stock.quantity;
    const newQuantity = previousQuantity + adjustStockDto.quantity;

    if (newQuantity < 0) {
      throw new BadRequestException('Stock quantity cannot be negative');
    }

    stock.quantity = newQuantity;
    const updatedStock = await this.stockRepository.save(stock);

    // Log stock adjustment
    await this.logsService.create({
      level: 'info',
      action: adjustStockDto.quantity > 0 ? 'stock_added' : 'stock_removed',
      message: `Stock quantity ${adjustStockDto.quantity > 0 ? 'increased' : 'decreased'} for "${stock.product}" by ${username}`,
      details: JSON.stringify({
        stockId: id,
        product: stock.product,
        previousQuantity,
        newQuantity,
        quantityChange: adjustStockDto.quantity,
        notes: adjustStockDto.notes,
      }),
      userId: username,
    });

    return updatedStock;
  }

  async remove(id: number, username: string): Promise<void> {
    const stock = await this.findOne(id);
    const productName = stock.product;
    await this.stockRepository.remove(stock);

    // Log deletion
    await this.logsService.create({
      level: 'info',
      action: 'stock_deleted',
      message: `Stock item "${productName}" deleted by ${username}`,
      details: JSON.stringify({
        stockId: id,
        product: productName,
        category: stock.category,
        quantity: stock.quantity,
      }),
      userId: username,
    });
  }

  async getLowStock(): Promise<Stock[]> {
    // Since minStockLevel doesn't exist in entity, return empty or implement custom logic
    return this.stockRepository
      .createQueryBuilder('stock')
      .where('stock.quantity <= 0')
      .getMany();
  }
}
