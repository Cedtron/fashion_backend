import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  ParseIntPipe,
  Query,
  UseGuards,
  Request,
  UseInterceptors,
  UploadedFile,
  ParseFilePipe,
  MaxFileSizeValidator,
  FileTypeValidator,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery, ApiConsumes, ApiBody } from '@nestjs/swagger';
import { StockService } from './stock.service';
import { CreateStockDto } from './dto/create-stock.dto';
import { UpdateStockDto } from './dto/update-stock.dto';
import { AdjustStockDto } from './dto/adjust-stock.dto';
import { SearchStockDto } from './dto/search-stock.dto';
import { Stock } from '../entities/stock.entity';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { diskStorage } from 'multer';
import { extname } from 'path';

@ApiTags('stock')
@ApiBearerAuth('JWT-auth')
@UseGuards(JwtAuthGuard)
@Controller('stock')
export class StockController {
  constructor(private readonly stockService: StockService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new stock item' })
  @ApiResponse({ status: 201, description: 'Stock created successfully', type: Stock })
  create(@Body() createStockDto: CreateStockDto, @Request() req) {
    const username = req.user?.username || req.user?.email || 'system';
    return this.stockService.create(createStockDto, username);
  }

  @Post(':id/image')
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './uploads/stock',
        filename: (req, file, cb) => {
          const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
          const ext = extname(file.originalname);
          cb(null, `stock-${req.params.id}-${uniqueSuffix}${ext}`);
        },
      }),
      limits: {
        fileSize: 5 * 1024 * 1024, // 5MB
      },
    }),
  )
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @ApiOperation({ summary: 'Upload image for stock item' })
  @ApiResponse({ status: 200, description: 'Image uploaded successfully' })
  async uploadImage(
    @Param('id', ParseIntPipe) id: number,
    @UploadedFile(
      new ParseFilePipe({
        validators: [
          new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
          new FileTypeValidator({ fileType: /(jpg|jpeg|png|gif)$/ }),
        ],
      }),
    )
    file: Express.Multer.File,
    @Request() req,
  ) {
    const username = req.user?.username || req.user?.email || 'system';
    const stock = await this.stockService.findOne(id);
    // Store relative path for serving
    const imagePath = `/uploads/stock/${file.filename}`;
    return this.stockService.update(id, { imagePath } as UpdateStockDto, username);
  }

  @Get()
  @ApiOperation({ summary: 'Get all stock items or search' })
  @ApiQuery({ name: 'name', required: false, type: String })
  @ApiQuery({ name: 'sku', required: false, type: String })
  @ApiQuery({ name: 'barcode', required: false, type: String })
  @ApiQuery({ name: 'categoryId', required: false, type: Number })
  @ApiQuery({ name: 'supplierId', required: false, type: Number })
  @ApiQuery({ name: 'brand', required: false, type: String })
  @ApiResponse({ status: 200, description: 'List of stock items', type: [Stock] })
  findAll(@Query() searchDto: SearchStockDto) {
    if (Object.keys(searchDto).length > 0) {
      return this.stockService.search(searchDto);
    }
    return this.stockService.findAll();
  }

  @Get('low-stock')
  @ApiOperation({ summary: 'Get stock items with low quantity' })
  @ApiResponse({ status: 200, description: 'List of low stock items', type: [Stock] })
  getLowStock() {
    return this.stockService.getLowStock();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a stock item by ID' })
  @ApiResponse({ status: 200, description: 'Stock found', type: Stock })
  @ApiResponse({ status: 404, description: 'Stock not found' })
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.stockService.findOne(id);
  }

  @Get(':id/history')
  @ApiOperation({ summary: 'Get stock change history' })
  @ApiResponse({ status: 200, description: 'Stock history' })
  async getHistory(@Param('id', ParseIntPipe) id: number) {
    const stock = await this.stockService.findOne(id);
    return stock.history;
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update a stock item' })
  @ApiResponse({ status: 200, description: 'Stock updated successfully', type: Stock })
  @ApiResponse({ status: 404, description: 'Stock not found' })
  update(@Param('id', ParseIntPipe) id: number, @Body() updateStockDto: UpdateStockDto, @Request() req) {
    const username = req.user?.username || req.user?.email || 'system';
    return this.stockService.update(id, updateStockDto, username);
  }

  @Patch(':id/adjust')
  @ApiOperation({ summary: 'Adjust stock quantity (add or remove)' })
  @ApiResponse({ status: 200, description: 'Stock adjusted successfully', type: Stock })
  @ApiResponse({ status: 404, description: 'Stock not found' })
  adjustStock(@Param('id', ParseIntPipe) id: number, @Body() adjustStockDto: AdjustStockDto, @Request() req) {
    const username = req.user?.username || req.user?.email || 'system';
    return this.stockService.adjustStock(id, adjustStockDto, username);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a stock item' })
  @ApiResponse({ status: 200, description: 'Stock deleted successfully' })
  @ApiResponse({ status: 404, description: 'Stock not found' })
  remove(@Param('id', ParseIntPipe) id: number, @Request() req) {
    const username = req.user?.username || req.user?.email || 'system';
    return this.stockService.remove(id, username);
  }
}

