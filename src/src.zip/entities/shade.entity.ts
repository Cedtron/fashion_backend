import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';
import { Stock } from './stock.entity';

@Entity("shade")
export class Shade {
@PrimaryGeneratedColumn()
id: number;


@Column()
shadeNo: string;


@Column()
colorName: string;


@Column()
color: string; // hex


@Column({ type: "int" })
quantity: number;


@Column()
unit: string; // Rolls, Pieces, Boxes


@Column({ type: "float" })
length: number;


@Column()
lengthUnit: string; // Yards, Meters, Inches


@ManyToOne(() => Stock, (stock) => stock.shades, { onDelete: "CASCADE" })
stock: Stock;
}

